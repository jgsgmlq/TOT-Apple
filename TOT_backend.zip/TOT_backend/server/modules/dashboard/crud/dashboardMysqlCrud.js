'use strict';

const { get, all, run, ensureDashboardInsightsTable } = require('../../common/db/mysql');

// ═══════════════════════════════════════════════════════════════════
// 原子数据查询 — 仅做 SELECT + JOIN + WHERE，不含任何聚合/子查询
// ═══════════════════════════════════════════════════════════════════

async function getTaskById(taskPublishId) {
  if (!taskPublishId) return null;
  return await get(
    `SELECT tp.*, ca.task_week, ca.topic_name, ca.model_type
     FROM task_publish tp
     LEFT JOIN campaign_activity ca ON ca.activity_id = tp.activity_id
     WHERE tp.task_publish_id = ?`,
    [taskPublishId]
  );
}

// ─── Queue ─────────────────────────────────────────────────────────

async function getQueueEntries({ taskPublishId, storeAppleId, rtm4Name, resellerName, subRegionCode, emailId, limit, offset } = {}) {
  if (!taskPublishId) return [];
  const cond = ['ltq.task_publish_id = ?'];
  const params = [taskPublishId];

  if (storeAppleId)  { cond.push('la.store_apple_id = ?'); params.push(storeAppleId); }
  if (rtm4Name)      { cond.push('rs.rtm4_name = ?'); params.push(rtm4Name); }
  if (resellerName)  { cond.push('rs.reseller_name = ?'); params.push(resellerName); }
  if (subRegionCode) { cond.push('rs.sub_region_code = ?'); params.push(subRegionCode); }
  if (emailId)       { cond.push('ltq.email_id = ?'); params.push(emailId); }

  const where = 'WHERE ' + cond.join(' AND ');
  const sql = `SELECT ltq.queue_id, ltq.email_id, ltq.priority_level,
                      la.store_apple_id, la.rtm_level_3_name, la.rtm_level_4_name,
                      la.user_business_role_name, la.apple_role_name,
                      rs.store_name, rs.rtm4_name, rs.reseller_name, rs.sub_region_code
               FROM learner_task_queue ltq
               JOIN learner_account la ON la.email_id = ltq.email_id AND la.user_enabled_indicator = 1
               LEFT JOIN reseller_store rs ON rs.store_apple_id = la.store_apple_id
               ${where}
               ORDER BY ltq.queue_id
               LIMIT ? OFFSET ?`;

  return await all(sql, [...params, limit || 1000, offset || 0]);
}

async function countQueueByTask(taskPublishId) {
  if (!taskPublishId) return { total: 0, total_stores: 0 };
  return await get(
    `SELECT COUNT(*) AS total, COUNT(DISTINCT la.store_apple_id) AS total_stores
     FROM learner_task_queue ltq
     JOIN learner_account la ON la.email_id = ltq.email_id AND la.user_enabled_indicator = 1
     WHERE ltq.task_publish_id = ?`,
    [taskPublishId]
  );
}

// ─── MyPal ──────────────────────────────────────────────────────────

async function getMyPalProgressByWeek(taskWeek) {
  if (!taskWeek) return [];
  return await all(
    'SELECT * FROM mypal_learning_progress_sync WHERE task_week = ?',
    [taskWeek]
  );
}

async function getMyPalProgressByEmails(emailIds, limit = 500) {
  if (!emailIds || emailIds.length === 0) return [];
  const placeholders = emailIds.map(() => '?').join(',');
  return await all(
    `SELECT * FROM mypal_learning_progress_sync
     WHERE email_id IN (${placeholders})
     ORDER BY synced_at DESC
     LIMIT ?`,
    [...emailIds, limit]
  );
}

// ─── Reminder / Confirmation ────────────────────────────────────────

async function getConfirmationStatus({ taskPublishId, emailIds } = {}) {
  if (!taskPublishId || !emailIds || emailIds.length === 0) return [];
  const ids = emailIds.length > 1000 ? emailIds.slice(0, 1000) : emailIds;
  const placeholders = ids.map(() => '?').join(',');
  return await all(
    `SELECT DISTINCT email_id FROM task_reminder_log
     WHERE task_publish_id = ?
       AND email_id IN (${placeholders})
       AND reminder_result = 'success'`,
    [taskPublishId, ...ids]
  );
}

async function getReminderList({ taskPublishId, emailId, limit = 1000, offset = 0 } = {}) {
  if (!taskPublishId) return [];
  const cond = ['task_publish_id = ?'];
  const params = [taskPublishId];
  if (emailId) { cond.push('email_id = ?'); params.push(emailId); }
  const where = 'WHERE ' + cond.join(' AND ');

  return await all(
    `SELECT * FROM learner_task_reminder ${where}
     ORDER BY reminder_id DESC LIMIT ? OFFSET ?`,
    [...params, limit, offset]
  );
}

async function getRemindersByTaskId(taskPublishId) {
  if (!taskPublishId) return [];
  return await all(
    `SELECT email_id, reminder_level FROM learner_task_reminder
     WHERE task_publish_id = ?`,
    [taskPublishId]
  );
}

async function getReminderLogs({ taskPublishId, emailId, limit = 1000, offset = 0 } = {}) {
  if (!taskPublishId) return [];
  const cond = ['trl.task_publish_id = ?'];
  const params = [taskPublishId];
  if (emailId) { cond.push('trl.email_id = ?'); params.push(emailId); }
  const where = 'WHERE ' + cond.join(' AND ');

  return await all(
    `SELECT trl.*, rs.store_name
     FROM task_reminder_log trl
     LEFT JOIN learner_account la ON la.email_id = trl.email_id
     LEFT JOIN reseller_store rs ON rs.store_apple_id = la.store_apple_id
     ${where}
     ORDER BY trl.reminder_at DESC LIMIT ? OFFSET ?`,
    [...params, limit, offset]
  );
}

// ─── Agent: dispatched tasks ─────────────────────────────────────

async function getActiveDispatchedTasks() {
  return await all(
    `SELECT task_publish_id, task_title, due_date, publish_status
     FROM task_publish
     WHERE publish_status = 'dispatched'
       AND (due_date IS NULL OR due_date >= NOW())
     ORDER BY due_date ASC`
  );
}

async function getExpiredDispatchedTasksCount() {
  const row = await get(
    `SELECT COUNT(*) AS cnt FROM task_publish
     WHERE publish_status = 'dispatched'
       AND due_date IS NOT NULL
       AND due_date < NOW()`
  );
  return row ? row.cnt : 0;
}

// ─── dashboard_insights ───────────────────────────────────────────

let insightsTableReady = false;
let insightsTablePromise = null;

async function readyInsightsTable() {
  if (insightsTableReady) return;
  if (!insightsTablePromise) {
    insightsTablePromise = ensureDashboardInsightsTable().then(() => {
      insightsTableReady = true;
    }).catch(err => {
      insightsTablePromise = null;
      throw err;
    });
  }
  await insightsTablePromise;
}

async function insertAgentInsight(id, moduleType, content, contextJson, userId) {
  await readyInsightsTable();
  await run(
    `INSERT INTO dashboard_insights
     (id, module_type, content, context_json, created_by)
     VALUES (?, ?, ?, ?, ?)`,
    [id, moduleType, content, contextJson, userId || 'system']
  );
}

async function getLatestAgentInsight() {
  await readyInsightsTable();
  return await get(
    `SELECT context_json, created_at FROM dashboard_insights
     WHERE module_type = 'global_agent'
     ORDER BY created_at DESC LIMIT 1`
  );
}

async function insertInsight(data) {
  await readyInsightsTable();
  await run(
    `INSERT INTO dashboard_insights
     (id, module_type, task_publish_id, filter_rtm, filter_format, filter_dealer_name,
      filter_store_id, extra_params_json, content, context_json, created_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [data.id, data.moduleType, data.taskPublishId || null,
     data.filterRtm || null, data.filterFormat || null, data.filterDealerName || null,
     data.filterStoreId || null, JSON.stringify(data.extraParams || {}),
     data.content, JSON.stringify(data.context || {}), data.createdBy || 'system']
  );
}

async function getInsightById(id) {
  await readyInsightsTable();
  return await get('SELECT * FROM dashboard_insights WHERE id = ?', [id]);
}

async function incrementInsightVote(id, voteType) {
  await readyInsightsTable();
  const col = voteType === 'up' ? 'up_count' : 'down_count';
  await run(`UPDATE dashboard_insights SET ${col} = ${col} + 1 WHERE id = ?`, [id]);
}

async function decrementInsightVote(id, voteType) {
  await readyInsightsTable();
  const col = voteType === 'up' ? 'up_count' : 'down_count';
  await run(`UPDATE dashboard_insights SET ${col} = ${col} - 1 WHERE id = ? AND ${col} > 0`, [id]);
}

async function searchTasks(keyword) {
  return await all(
    `SELECT * FROM task_publish WHERE task_title LIKE ?`,
    [`%${keyword}%`]
  );
}

async function getInsightVotes(id) {
  await readyInsightsTable();
  return await get('SELECT up_count AS up, down_count AS down FROM dashboard_insights WHERE id = ?', [id]);
}

module.exports = {
  getTaskById,
  getQueueEntries,
  countQueueByTask,
  getMyPalProgressByWeek,
  getMyPalProgressByEmails,
  getConfirmationStatus,
  getReminderList,
  getRemindersByTaskId,
  getReminderLogs,
  getActiveDispatchedTasks,
  getExpiredDispatchedTasksCount,
  insertAgentInsight,
  getLatestAgentInsight,
  searchTasks,
  insertInsight,
  getInsightById,
  incrementInsightVote,
  decrementInsightVote,
  getInsightVotes,
};
